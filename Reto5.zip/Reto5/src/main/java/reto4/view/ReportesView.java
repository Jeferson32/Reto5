package reto4.view;

import java.util.List;
import reto4.controller.ReportesController;
import reto4.model.vo.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.*;

public class ReportesView extends JFrame implements ActionListener {

    private ReportesController controller;
    private JMenuBar menuBar;
    private JMenu menu;
    private JRadioButton primerInf, segundoInf,tercerInf;
    private JTable tabla;
    private DefaultTableModel modelo;
    private JLabel lblTitulo, lblCosulta;
    private ButtonGroup grupoDeInformes;

    public ReportesView() {
        controller = new ReportesController();
        menu();
        etiqueta1();
        etiqueta2();
        tabla();
    }

    public void menu() {
        menuBar = new JMenuBar();
        setJMenuBar(menuBar);
        menu = new JMenu("Informes");
        menuBar.add(menu);
        primerInf = new JRadioButton("Primer Informe", false);
        segundoInf = new JRadioButton("Segundo Informe", false);
        tercerInf = new JRadioButton("Tercer Informe", false);
        grupoDeInformes = new ButtonGroup();
        grupoDeInformes.add(primerInf);
        grupoDeInformes.add(segundoInf);
        grupoDeInformes.add(tercerInf);
        menu.add(primerInf);
        menu.add(segundoInf);
        menu.add(tercerInf);
        primerInf.addActionListener(this);
        segundoInf.addActionListener(this);
        tercerInf.addActionListener(this);
    }

    public void etiqueta1() {
        lblTitulo = new JLabel("Informe Reto 5",SwingConstants.CENTER);
        lblTitulo.setPreferredSize(new Dimension(500, 30));
        lblTitulo.setFont(new Font("Forte", Font.BOLD, 30));
        add(lblTitulo);
    }

    public void etiqueta2() {
        lblCosulta = new JLabel();
        lblCosulta.setPreferredSize(new Dimension(500, 30));
        lblCosulta.setFont(new Font("Forte", Font.BOLD, 20));
        add(lblCosulta);
    }

    public void tabla() {
        tabla = new JTable(modelo);
        tabla.setPreferredScrollableViewportSize(new Dimension(500, 200));
        add(tabla);
        JScrollPane pane = new JScrollPane(tabla);
        add(pane);
    }

    public void lideres() {
        try {
            List<ListarLideresVo> lideres = controller.listarLideres();
            modelo = new DefaultTableModel();
            modelo.addColumn("Id Lider");
            modelo.addColumn("Nombre");
            modelo.addColumn("Apellido");
            modelo.addColumn("Ciudad");
            for (ListarLideresVo i : lideres) {
                Object[] fila = new Object[4];
                fila[0] = i.getId();
                fila[1] = i.getNombre();
                fila[2] = i.getApellido();
                fila[3] = i.getCiudad();
                modelo.addRow(fila);
            }
            tabla.setModel(modelo);
            modelo.fireTableDataChanged();
        } catch (Exception e) {
            System.out.println("Error " + e.getMessage());
        }
    }

    public void proyectos() {
        try {
            List<ProyectosVo> proyectos = controller.listarProyectos();
            modelo = new DefaultTableModel();
            modelo.addColumn("Id proyecto");
            modelo.addColumn("Constructora");
            modelo.addColumn("Habitaciones");
            modelo.addColumn("Ciudad");
            for (ProyectosVo proyecto : proyectos) {
                Object[] fila = new Object[4];
                fila[0] = proyecto.getId();
                fila[1] = proyecto.getConstructora();
                fila[2] = proyecto.getHabitaciones();
                fila[3] = proyecto.getCiudad();
                modelo.addRow(fila);
            }
            tabla.setModel(modelo);
            modelo.fireTableDataChanged();
        } catch (Exception e) {
            System.out.println("Error " + e.getMessage());
        }
    }

    public void compras() {
        try{
            List<ComprasVo> compras = controller.listarCompras();
            modelo = new DefaultTableModel();
            modelo.addColumn("Id compra");
            modelo.addColumn("Constructora");
            modelo.addColumn("Banco Vinculado");
            
            for(ComprasVo compra: compras){
                Object[] fila = new Object[3];
                fila[0]= compra.getId();
                fila[1]= compra.getConstructora();
                fila[2]= compra.getBanco();
                modelo.addRow(fila);                 
            }
            tabla.setModel(modelo);
            modelo.fireTableDataChanged();
        }
        catch(Exception e){
            System.out.println("Error: " + e.getMessage());
        }
    
}

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == primerInf) {
            lideres();
            lblCosulta.setText("Informe de líderes");
        }
        if (e.getSource() == segundoInf) {
            proyectos();
            lblCosulta.setText("Informe de Proyectos");
        }
        if(e.getSource()  == tercerInf){
            compras();
            lblCosulta.setText("Informe de Compras");
        }
    }
}
